package mk.ukim.finki.chartair.service;

import mk.ukim.finki.chartair.model.Flight;

import java.util.List;

public interface FlightService {
List<Flight> listAll();
}
