package mk.ukim.finki.chartair.model.exceptions;

public class InvalidUsernameOrPasswordException extends RuntimeException{
}
