package mk.ukim.finki.chartair.model;

public enum TravelClass {
    ECONOMY,
    BUSINESS,
    FIRST_CLASS
}
