package mk.ukim.finki.chartair.model;

import lombok.Data;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import javax.persistence.*;
import java.util.Collection;
import java.util.List;

@Data
@Entity
@Table(name = "app_users")
public class User {

    @Id
    private String username;

    private String password;

    private String name;

    private String surname;


    @Enumerated(value = EnumType.STRING)
    private Role role;


    @OneToMany(mappedBy = "user", fetch = FetchType.EAGER)
    private List<Cart> carts;

    public User(){

    }
   public User(String username, String password,String name, String surname,Role role){
       this.username = username;
       this.password = password;
       this.name = name;
       this.surname = surname;
       this.role = role;

   }
}
