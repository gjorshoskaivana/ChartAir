package mk.ukim.finki.chartair.service;

public interface PassengerService {
}
